let dropFileZone=document.querySelector(".main__drop-target-file-container");

dropFileZone.addEventListener('click',(e)=>{
        document.showFilePicker();
});